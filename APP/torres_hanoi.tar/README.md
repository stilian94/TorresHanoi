# [⛩ Tower of Hanoi JavaScript 🏯](https://ayidouble.github.io/Tower-of-Hanoi-JavaScript/)
⛩ **Tower of Hanoi**, a mathematical game. Realized with **draggable** HTML Elements and Buttons 🏯

The **Disks** are **draggable**, they can either be moved per **Drag & Drop** or with the **Buttons**.

## 🖼 Images 🖼

![Türme von Hanoi JavaScript HTML CSS](Images/Türme_von_Hanoi_1.png)
![Türme von Hanoi JavaScript HTML CSS](Images/Türme_von_Hanoi_2.png)
![Türme von Hanoi JavaScript HTML CSS](Images/Türme_von_Hanoi_3.png)
![Türme von Hanoi JavaScript HTML CSS](Images/Türme_von_Hanoi_4.png)
![Türme von Hanoi JavaScript HTML CSS](Images/Türme_von_Hanoi_5.png)
